# Getting Started - Enhanced Data Profiler (5 Minutes)

## 🚀 Installation

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Download JDBC Driver (Optional)
Only needed if you want to profile JDBC databases (Oracle, MySQL, SQL Server, Redshift, etc.)

```bash
# Example: Oracle
mkdir -p ~/jdbc_drivers
# Download ojdbc8.jar from https://www.oracle.com/database/technologies/appdev/jdbc/
# Or use wget/curl
wget https://download.oracle.com/otn-pub/java/jdbc/ojdbc8.jar -O ~/jdbc_drivers/ojdbc8.jar
```

---

## 🎯 5-Minute Quick Start

### 1. Profile a CSV File (30 seconds)

```python
from profiler_api_unified import profile_data

# Load and profile CSV
profiler = profile_data('data.csv', source='csv')

# Get quality report
print(profiler.get_quality_report())

# Get summary
print(profiler.get_profile_summary())
```

### 2. Detect PII in Your Data (1 minute)

```python
from profiler_api_unified import profile_data

profiler = profile_data('customers.csv', source='csv')

# Check for PII
summary = profiler.get_profile_summary()
print(f"PII Columns: {summary['pii_columns']}")

# Detailed PII detection
metrics = profiler.profile_enhanced_columns()
for m in metrics:
    if m.pii_detected:
        print(f"PII found in {m.column_name}: {m.pii_detected}")
```

### 3. Analyze Data Quality (1 minute)

```python
from profiler_api_unified import profile_data

profiler = profile_data('data.csv', source='csv')

# Get detailed metrics
metrics = profiler.profile_enhanced_columns()

for m in metrics:
    print(f"\n{m.column_name}:")
    print(f"  Quality Score: {m.quality_score:.1f}%")
    print(f"  Nulls: {m.null_count} ({m.null_percentage:.1f}%)")
    print(f"  Duplicates: {m.duplicate_count} ({m.duplicate_percentage:.1f}%)")
```

### 4. Profile Database (Oracle Example) (2 minutes)

```python
from profiler_api_unified import DataLoader, EnhancedDataProfiler

# Load single table from Oracle
df = DataLoader.from_jdbc(
    'oracle',
    table_name='CUSTOMERS',
    host='oracle-server.com',
    service_name='ORCL',
    username='scott',
    password='tiger',
    driver_path='/path/to/ojdbc8.jar'
)

# Profile
profiler = EnhancedDataProfiler(df, table_name='CUSTOMERS')
print(profiler.get_quality_report())
```

### 5. Batch Profile Multiple Tables (2 minutes)

```python
from profiler_api_unified import DataLoader, BatchProfiler

# Load multiple tables
tables = DataLoader.from_postgres(
    host='localhost',
    database='mydb',
    user='postgres',
    password='password'
)

# Profile all
batch = BatchProfiler()
result = batch.profile_dataframes(tables)

# Export results
batch.export_json('profiles.json', result)
batch.export_csv('profiles.csv')

print(f"Total tables: {result.total_tables}")
print(f"Total columns: {result.total_columns}")
print(f"Average quality: {result.summary_stats['avg_quality']:.1f}%")
```

---

## 📊 Supported Data Sources

### Files
✅ CSV
✅ Parquet
✅ JSON
✅ Excel

### Databases
✅ PostgreSQL
✅ Snowflake

### JDBC (40+ Databases)
✅ Oracle
✅ MySQL / MariaDB
✅ SQL Server
✅ Amazon Redshift
✅ Teradata
✅ IBM DB2
✅ Vertica
✅ And 30+ more

---

## 🎛️ Usage Patterns

### Pattern 1: Profile Local File

```python
from profiler_api_unified import profile_data

profiler = profile_data('mydata.csv', source='csv')
report = profiler.get_quality_report()
summary = profiler.get_profile_summary()
```

### Pattern 2: Profile Database Table

```python
from profiler_api_unified import DataLoader, EnhancedDataProfiler

# Load from PostgreSQL
df = DataLoader.from_postgres(
    host='localhost',
    database='mydb',
    user='user',
    password='pass',
    table_name='users'
)

# Profile
profiler = EnhancedDataProfiler(df)
print(profiler.get_quality_report())
```

### Pattern 3: Profile JDBC Database

```python
from profiler_api_unified import DataLoader, EnhancedDataProfiler

# Load from Oracle
df = DataLoader.from_jdbc(
    'oracle',
    table_name='CUSTOMERS',
    host='oracle-server',
    service_name='ORCL',
    username='scott',
    password='tiger',
    driver_path='/path/to/ojdbc8.jar'
)

# Profile
profiler = EnhancedDataProfiler(df)
metrics = profiler.profile_enhanced_columns()
```

### Pattern 4: Batch Profile Multiple Sources

```python
from profiler_api_unified import DataLoader, BatchProfiler

# Load multiple tables
tables = {
    'csv_data': DataLoader.from_csv('data.csv'),
    'db_data': DataLoader.from_postgres(
        host='localhost',
        database='mydb',
        user='user',
        password='pass',
        table_name='orders'
    )
}

# Profile all
batch = BatchProfiler()
result = batch.profile_dataframes(tables)

# Export
batch.export_json('results.json', result)
```

### Pattern 5: Find PII and Duplicates

```python
from profiler_api_unified import profile_data

profiler = profile_data('customers.csv', source='csv')

# PII
summary = profiler.get_profile_summary()
for col in summary['pii_columns']:
    print(f"PII found in: {col}")

# Duplicates
duplicates = profiler.detect_exact_duplicates()
print(f"Duplicate rows: {duplicates['duplicate_rows']}")

# Fuzzy duplicates
fuzzy = profiler.detect_fuzzy_duplicates('customer_name')
print(f"Fuzzy duplicates: {len(fuzzy)}")
```

---

## 📝 Common Tasks

### Export Quality Report to CSV

```python
from profiler_api_unified import profile_data

profiler = profile_data('data.csv', source='csv')
report = profiler.get_quality_report()
report.to_csv('quality_report.csv', index=False)
```

### Find High-Quality Columns

```python
from profiler_api_unified import profile_data

profiler = profile_data('data.csv', source='csv')
metrics = profiler.profile_enhanced_columns()

good_columns = [m for m in metrics if m.quality_score >= 90]
print(f"High-quality columns: {[m.column_name for m in good_columns]}")
```

### Identify Columns with Nulls

```python
from profiler_api_unified import profile_data

profiler = profile_data('data.csv', source='csv')
metrics = profiler.profile_enhanced_columns()

null_columns = [m for m in metrics if m.null_percentage > 10]
for m in null_columns:
    print(f"{m.column_name}: {m.null_percentage:.1f}% nulls")
```

### Compare Data Quality Across Databases

```python
from profiler_api_unified import DataLoader, EnhancedDataProfiler, BatchProfiler

tables = {
    'oracle': DataLoader.from_jdbc('oracle', table_name='CUSTOMERS', ...),
    'mysql': DataLoader.from_jdbc('mysql', table_name='customers', ...),
    'postgres': DataLoader.from_postgres(host='localhost', database='mydb', ...)
}

batch = BatchProfiler()
result = batch.profile_dataframes(tables)

# Compare
for table, profile in result.table_profiles.items():
    quality = profile['summary']['avg_quality']
    print(f"{table}: {quality:.1f}%")
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Set credentials
export DB_HOST=oracle-server.com
export DB_USER=scott
export DB_PASSWORD=tiger
export JDBC_DRIVER=/path/to/ojdbc8.jar
```

```python
import os
from profiler_api_unified import DataLoader

df = DataLoader.from_jdbc(
    'oracle',
    table_name='CUSTOMERS',
    host=os.environ['DB_HOST'],
    username=os.environ['DB_USER'],
    password=os.environ['DB_PASSWORD'],
    driver_path=os.environ['JDBC_DRIVER']
)
```

### .env File

```bash
# .env
DB_HOST=oracle-server.com
DB_USER=scott
DB_PASSWORD=tiger
JDBC_DRIVER=/path/to/ojdbc8.jar
```

```python
from dotenv import load_dotenv
import os

load_dotenv()

df = DataLoader.from_jdbc(
    'oracle',
    table_name='CUSTOMERS',
    host=os.getenv('DB_HOST'),
    username=os.getenv('DB_USER'),
    password=os.getenv('DB_PASSWORD'),
    driver_path=os.getenv('JDBC_DRIVER')
)
```

---

## 🧪 Testing

### Run All Tests

```bash
pytest test_profiler_api_unified.py -v
```

### Run Specific Test Class

```bash
pytest test_profiler_api_unified.py::TestEnhancedDataProfiler -v
```

### Run with Coverage

```bash
pytest test_profiler_api_unified.py --cov=profiler_api_unified --cov-report=html
```

---

## 📚 Key Classes & Methods

### EnhancedDataProfiler
Main profiling class

```python
profiler = EnhancedDataProfiler(df, table_name='my_table')

# Methods
metrics = profiler.profile_enhanced_columns()    # Profile all columns
report = profiler.get_quality_report()           # Get DataFrame report
summary = profiler.get_profile_summary()         # Get summary dict

# PII & Duplicates
pii = profiler.detect_pii('column_name')        # Detect PII
duplicates = profiler.detect_exact_duplicates() # Find duplicates
fuzzy = profiler.detect_fuzzy_duplicates('col') # Fuzzy match

# Statistics
entropy = profiler.calculate_entropy('column')  # Entropy
stats = profiler.analyze_numeric_distribution('col') # Numeric stats
```

### DataLoader
Load data from any source

```python
# Files
df = DataLoader.from_csv('file.csv')
df = DataLoader.from_parquet('file.parquet')
df = DataLoader.from_json('file.json')
df = DataLoader.from_excel('file.xlsx')

# Databases
df = DataLoader.from_postgres(host='...', database='...', ...)
df = DataLoader.from_snowflake(account='...', ...)

# JDBC (40+ databases)
df = DataLoader.from_jdbc('oracle', table_name='...', ...)

# Chunked loading (large tables)
for df_chunk in DataLoader.from_jdbc_chunked('redshift', table_name='...', ...):
    # Process chunk
    pass
```

### BatchProfiler
Profile multiple tables

```python
batch = BatchProfiler()
result = batch.profile_dataframes({'table1': df1, 'table2': df2})

# Export
batch.export_json('profiles.json', result)
batch.export_csv('profiles.csv')
```

### Convenience Functions

```python
# Universal loader
df = load_data('csv', filepath='data.csv')
df = load_data('jdbc', database_type='oracle', ...)

# Universal profiler
profiler = profile_data('data.csv', source='csv')
profiler = profile_data(df)  # From DataFrame
result = profile_data({'t1': df1, 't2': df2})  # Multiple
```

---

## 🚨 Troubleshooting

### Error: "No suitable driver found"

**Cause**: JDBC driver JAR not found

**Solution**:
```python
from pathlib import Path

driver_path = '/path/to/ojdbc8.jar'
assert Path(driver_path).exists(), f"Driver not found: {driver_path}"
```

### Error: "java.lang.ClassNotFoundException"

**Cause**: Wrong driver class name

**Solution**: Check database-specific driver class:
- Oracle: `oracle.jdbc.driver.OracleDriver`
- MySQL: `com.mysql.cj.jdbc.Driver`
- SQL Server: `com.microsoft.sqlserver.jdbc.SQLServerDriver`

### Error: "Connection refused"

**Cause**: Database not running or wrong host/port

**Solution**: Verify connection parameters
```bash
# Test connectivity
nc -zv oracle-server.com 1521
```

### Error: "ImportError: jaydebeapi"

**Cause**: jaydebeapi not installed

**Solution**:
```bash
pip install jaydebeapi
```

---

## 💡 Tips & Best Practices

### 1. Large Tables
Use chunked loading for tables > 1M rows:
```python
for df_chunk in DataLoader.from_jdbc_chunked(
    'oracle',
    table_name='huge_table',
    chunk_size=50000,
    ...
):
    profiler = EnhancedDataProfiler(df_chunk)
    # Process chunk
```

### 2. Credentials
Never hardcode credentials:
```python
# ❌ Bad
df = DataLoader.from_postgres(password='MyPassword123!')

# ✅ Good
import os
from dotenv import load_dotenv
load_dotenv()
df = DataLoader.from_postgres(password=os.getenv('DB_PASSWORD'))
```

### 3. Error Handling
Always handle exceptions:
```python
try:
    df = DataLoader.from_jdbc('oracle', ...)
    profiler = EnhancedDataProfiler(df)
except Exception as e:
    print(f"Error: {e}")
    # Handle error
```

### 4. Performance
Optimize for large datasets:
```python
# Load only needed columns
df = DataLoader.from_postgres(
    query='SELECT col1, col2, col3 FROM table'
)

# Filter in database
df = DataLoader.from_postgres(
    query='SELECT * FROM table WHERE date >= CURRENT_DATE - 30'
)
```

---

## 📖 Next Steps

1. **Read**: README.md (comprehensive guide)
2. **Review**: Architecture guide (design patterns)
3. **Explore**: Examples (working code)
4. **Test**: Run test suite (verify installation)
5. **Integrate**: Use in your projects

---

## 🆘 Support

For detailed documentation, see:
- `README.md` - Complete API reference
- `ARCHITECTURE.md` - Design patterns
- `JDBC_SETUP_GUIDE.md` - Database setup
- `test_profiler_api_unified.py` - Test examples

---

## ✅ Checklist

- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Download JDBC driver (if needed)
- [ ] Run tests: `pytest test_profiler_api_unified.py -v`
- [ ] Try basic example: Profile a CSV file
- [ ] Try database example: Profile a database table
- [ ] Check documentation for your use case

**You're all set! Happy profiling! 🎉**
