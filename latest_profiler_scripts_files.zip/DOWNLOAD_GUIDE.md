# 📦 Download & Installation Guide

## Three Package Options

Choose the package that fits your needs:

### 🎯 Package 1: CORE (19 KB)
**enhanced_data_profiler_core.zip**

**Contents:**
- `profiler_api_unified.py` - Main API (all-in-one unified)
- `test_profiler_api_unified.py` - Comprehensive tests (60+ tests)
- `requirements.txt` - Dependencies
- `GETTING_STARTED.md` - Quick start (5 minutes)
- `README.md` - Complete reference

**Best for:**
- CSV, Parquet, JSON, Excel files
- PostgreSQL, Snowflake databases
- Small to medium datasets
- Quick profiling tasks

**Size:** 19 KB  
**Download:** ✅ Recommended for beginners

---

### 💼 Package 2: ENTERPRISE (37 KB)
**enhanced_data_profiler_enterprise.zip**

**Includes Core + JDBC Support:**
- Everything from CORE package
- `jdbc_connector.py` - JDBC connectivity
- `extended_data_loader.py` - Extended data loader
- `jdbc_examples.py` - 12 JDBC examples
- `JDBC_README.md` - JDBC API reference
- `JDBC_SETUP_GUIDE.md` - Database setup guide

**Best for:**
- Oracle databases
- MySQL / MariaDB
- SQL Server
- Amazon Redshift
- Teradata, DB2, Vertica
- Large enterprise databases
- 40+ JDBC-compatible databases

**Size:** 37 KB  
**Download:** ✅ Recommended for production

---

### 🚀 Package 3: COMPLETE (188 KB)
**enhanced_data_profiler_complete.zip**

**Includes Everything:**
- Everything from CORE and ENTERPRISE
- Original modular `profiler_api.py`
- CLI tool: `profile_cli.py`
- Streamlit UI: `app_streamlit.py`
- Multiple test suites (60+ tests each)
- 12 sample data files
- All documentation and guides
- All examples

**Best for:**
- Learning and experimentation
- Complete solution
- Multiple usage modes (API, CLI, UI)
- Research and development
- Integration reference

**Size:** 188 KB  
**Download:** ✅ Recommended for comprehensive solution

---

## 🚀 Installation Steps

### Step 1: Download a Package
Choose one of the three ZIP files above

### Step 2: Extract

**On Windows:**
```powershell
# Right-click ZIP → Extract All
# Or use:
Expand-Archive enhanced_data_profiler_core.zip -DestinationPath .
```

**On macOS/Linux:**
```bash
unzip enhanced_data_profiler_core.zip
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Verify Installation

```bash
# Test import
python -c "from profiler_api_unified import profile_data; print('✓ Installation successful!')"

# Or run tests
pytest test_profiler_api_unified.py -v
```

---

## 📖 Getting Started

### Quick Start (5 minutes)

Read `GETTING_STARTED.md` included in each package.

### Profile a CSV File

```python
from profiler_api_unified import profile_data

profiler = profile_data('data.csv', source='csv')
print(profiler.get_quality_report())
```

### Profile a Database

```python
from profiler_api_unified import DataLoader, EnhancedDataProfiler

# PostgreSQL
df = DataLoader.from_postgres(
    host='localhost',
    database='mydb',
    user='user',
    password='password',
    table_name='customers'
)

# Oracle (ENTERPRISE package only)
df = DataLoader.from_jdbc(
    'oracle',
    table_name='CUSTOMERS',
    host='oracle-server',
    service_name='ORCL',
    username='scott',
    password='tiger',
    driver_path='/path/to/ojdbc8.jar'
)

profiler = EnhancedDataProfiler(df)
print(profiler.get_quality_report())
```

---

## 📋 Package Comparison

| Feature | Core | Enterprise | Complete |
|---------|------|-----------|----------|
| **CSV, Parquet, JSON, Excel** | ✅ | ✅ | ✅ |
| **PostgreSQL** | ✅ | ✅ | ✅ |
| **Snowflake** | ✅ | ✅ | ✅ |
| **JDBC Databases (40+)** | ❌ | ✅ | ✅ |
| **PII Detection** | ✅ | ✅ | ✅ |
| **Quality Metrics** | ✅ | ✅ | ✅ |
| **Duplicate Detection** | ✅ | ✅ | ✅ |
| **Batch Processing** | ✅ | ✅ | ✅ |
| **Tests (60+)** | ✅ | ✅ | ✅ |
| **CLI Tool** | ❌ | ❌ | ✅ |
| **Streamlit UI** | ❌ | ❌ | ✅ |
| **Sample Data** | ❌ | ❌ | ✅ |
| **Size** | 19 KB | 37 KB | 188 KB |

---

## 🎯 Recommended Packages by Use Case

### I want to profile CSV files
→ **CORE** package ✅

### I need PostgreSQL support
→ **CORE** package ✅

### I need Oracle/MySQL/SQL Server
→ **ENTERPRISE** package ✅

### I want everything
→ **COMPLETE** package ✅

### I'm learning/experimenting
→ **COMPLETE** package ✅

### I need a production deployment
→ **ENTERPRISE** package ✅

---

## 📚 Documentation Structure

### In CORE Package:
- `README.md` - Complete API reference
- `GETTING_STARTED.md` - 5-minute quick start
- `requirements.txt` - Dependencies

### In ENTERPRISE Package (adds):
- `JDBC_README.md` - JDBC API reference
- `JDBC_SETUP_GUIDE.md` - Database setup for each DB
- `jdbc_examples.py` - 12 working examples

### In COMPLETE Package (adds):
- `ARCHITECTURE.md` - Design patterns
- `QUICKSTART.md` - Copy-paste examples
- `TESTING_GUIDE.md` - Testing documentation
- `sample_data/` - 12 test datasets
- All other utilities and examples

---

## 🆘 Troubleshooting

### "ImportError: No module named 'polars'"
```bash
pip install -r requirements.txt
```

### "No suitable JDBC driver found"
- Ensure you're using ENTERPRISE or COMPLETE package
- Download JDBC driver for your database (see `JDBC_SETUP_GUIDE.md`)

### "Connection refused"
- Verify database host and port
- Check firewall settings
- Test connectivity: `nc -zv hostname port`

### "TypeError: pandas DataFrame"
The unified API supports both Polars and Pandas:
```python
# Both work:
profiler = EnhancedDataProfiler(polars_df)
profiler = EnhancedDataProfiler(pandas_df)
```

---

## 🔧 Minimal Installation

If you only need core functionality:

```bash
# Extract CORE package
unzip enhanced_data_profiler_core.zip

# Install only essential dependencies
pip install polars pandas numpy scipy

# Test
python -c "from profiler_api_unified import profile_data; print('✓ OK')"
```

---

## 📦 Next Steps After Installation

1. **Read the documentation** (5 min)
   - `GETTING_STARTED.md` - Quick start
   - `README.md` - Complete reference

2. **Run a test** (2 min)
   ```bash
   pytest test_profiler_api_unified.py -v
   ```

3. **Try your first profile** (5 min)
   ```python
   from profiler_api_unified import profile_data
   profiler = profile_data('data.csv', source='csv')
   print(profiler.get_quality_report())
   ```

4. **Explore examples** (10 min)
   - Check `README.md` for working examples
   - Review test file for test cases
   - Check `JDBC_EXAMPLES.py` (ENTERPRISE/COMPLETE only)

5. **Integrate with your project** (30 min)
   - Copy `profiler_api_unified.py` to your project
   - Import and use in your code
   - Adjust as needed for your use case

---

## 📝 Files in Each Package

### CORE Package Contents:
```
enhanced_data_profiler_core/
├── profiler_api_unified.py        # Main API (2000+ lines)
├── test_profiler_api_unified.py   # Tests (60+ tests)
├── README.md                      # Full reference
├── GETTING_STARTED.md             # Quick start
└── requirements.txt               # Dependencies
```

### ENTERPRISE Package Contents:
```
enhanced_data_profiler_enterprise/
├── [All CORE files]
├── jdbc_connector.py              # JDBC support
├── extended_data_loader.py        # Extended loader
├── jdbc_examples.py               # 12 JDBC examples
├── JDBC_README.md                 # JDBC reference
└── JDBC_SETUP_GUIDE.md            # Database setup
```

### COMPLETE Package Contents:
```
enhanced_data_profiler_complete/
├── [All ENTERPRISE files]
├── profiler_api.py                # Original modular API
├── profile_cli.py                 # CLI tool
├── app_streamlit.py               # Streamlit UI
├── examples.py                    # Basic examples
├── generate_sample_data.py        # Sample data generator
├── test_profiler_api.py           # Original test suite
├── ARCHITECTURE.md                # Design patterns
├── QUICKSTART.md                  # Detailed examples
├── TESTING_GUIDE.md               # Testing info
├── sample_data/                   # 12 test datasets
│   ├── customers.csv
│   ├── orders.csv
│   ├── products.csv
│   ├── transactions.csv
│   ├── users.csv
│   ├── events.csv
│   ├── sales.csv
│   ├── *.json files
│   └── *.sql files
└── [All documentation]
```

---

## ⚡ Quick Reference

### CORE Package (Quick Profiling)
```bash
unzip enhanced_data_profiler_core.zip
pip install -r requirements.txt
python
>>> from profiler_api_unified import profile_data
>>> profiler = profile_data('data.csv', source='csv')
>>> print(profiler.get_quality_report())
```

### ENTERPRISE Package (Database Profiling)
```bash
unzip enhanced_data_profiler_enterprise.zip
pip install -r requirements.txt
# Download JDBC driver (see JDBC_SETUP_GUIDE.md)
python
>>> from profiler_api_unified import DataLoader, EnhancedDataProfiler
>>> df = DataLoader.from_jdbc('oracle', ...)
>>> profiler = EnhancedDataProfiler(df)
>>> print(profiler.get_profile_summary())
```

### COMPLETE Package (Everything)
```bash
unzip enhanced_data_profiler_complete.zip
pip install -r requirements.txt
python
>>> from profiler_api_unified import profile_data
>>> profiler = profile_data('data.csv', source='csv')

# Also available:
# - CLI: python profile_cli.py
# - UI: streamlit run app_streamlit.py
# - Tests: pytest test_profiler_api_unified.py -v
```

---

## ✅ Checklist

Before you start:
- [ ] Download the right package for your use case
- [ ] Extract the ZIP file
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Verify: `python -c "from profiler_api_unified import profile_data"`
- [ ] Read: `GETTING_STARTED.md`
- [ ] Run: `pytest test_profiler_api_unified.py -v`
- [ ] Try: Profile your first file/database

---

## 📞 Support

**For quick answers:**
1. Read `GETTING_STARTED.md` (5 min)
2. Check `README.md` (10 min)
3. Review test file examples (10 min)

**For database-specific help:**
- ENTERPRISE/COMPLETE: See `JDBC_SETUP_GUIDE.md`

**For advanced usage:**
- COMPLETE: See `ARCHITECTURE.md`

---

**Ready to get started? Download a package above!** 🚀
