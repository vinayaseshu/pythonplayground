# DuckDB EDA App with Streamlit

A simple exploratory data analysis (EDA) application powered by DuckDB and Streamlit that supports multiple file formats.

## Features

- 📁 **Multi-format Support**: CSV, Parquet, JSON, Excel (.xlsx, .xls)
- 📊 **Interactive Visualizations**: Histograms, box plots, bar charts, correlation heatmaps
- 🔍 **Data Preview**: View head, tail, or random samples
- 📈 **Statistical Analysis**: Automatic summary statistics for numeric and categorical data
- 💻 **SQL Query Interface**: Run custom DuckDB SQL queries on your data
- 📥 **Export Capabilities**: Download processed data and query results

## Installation

1. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Usage

1. Run the Streamlit app:

```bash
streamlit run duckdb_eda_app.py
```

2. Open your browser (usually at `http://localhost:8501`)

3. Upload your data file using the file uploader

4. Explore your data across the different tabs:
   - **Overview**: Dataset statistics and column information
   - **Data Preview**: Browse your data
   - **Visualizations**: Interactive charts
   - **Statistics**: Detailed summaries
   - **SQL Query**: Custom queries with DuckDB

## Supported File Formats

- **CSV** (.csv) - Comma-separated values
- **Parquet** (.parquet) - Columnar storage format
- **JSON** (.json) - JavaScript Object Notation
- **Excel** (.xlsx, .xls) - Microsoft Excel files

## Key Features Explained

### Overview Tab
- Total rows and columns
- Memory usage
- Duplicate row detection
- Column-level information (data types, null values, unique counts)

### Visualizations Tab
- Distribution plots for numeric columns
- Box plots for outlier detection
- Bar charts for categorical data
- Correlation heatmaps

### SQL Query Tab
- Run custom DuckDB SQL queries
- Preset query templates
- Download query results as CSV

## Example Queries

```sql
-- Count total rows
SELECT COUNT(*) as total_rows FROM data

-- Group by and count
SELECT column_name, COUNT(*) as count 
FROM data 
GROUP BY column_name 
ORDER BY count DESC

-- Filter and aggregate
SELECT * FROM data 
WHERE numeric_column > 100 
LIMIT 10
```

## Requirements

- Python 3.8+
- streamlit
- duckdb
- pandas
- plotly
- openpyxl (for Excel support)

## License

MIT
