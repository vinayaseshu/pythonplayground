import streamlit as st
import duckdb
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(page_title="DuckDB EDA App", layout="wide")

st.title("🦆 DuckDB Exploratory Data Analysis")
st.markdown("Upload any data file (CSV, Parquet, JSON, Excel) for instant analysis")

# Initialize DuckDB connection
@st.cache_resource
def get_db_connection():
    return duckdb.connect(':memory:')

conn = get_db_connection()

# File upload
uploaded_file = st.file_uploader(
    "Choose a file", 
    type=['csv', 'parquet', 'json', 'xlsx', 'xls']
)

if uploaded_file is not None:
    # Save uploaded file temporarily
    file_path = f"/tmp/{uploaded_file.name}"
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    # Determine file type and read with DuckDB
    file_extension = Path(uploaded_file.name).suffix.lower()
    
    try:
        if file_extension == '.csv':
            df = conn.execute(f"SELECT * FROM read_csv_auto('{file_path}')").df()
        elif file_extension == '.parquet':
            df = conn.execute(f"SELECT * FROM read_parquet('{file_path}')").df()
        elif file_extension == '.json':
            df = conn.execute(f"SELECT * FROM read_json_auto('{file_path}')").df()
        elif file_extension in ['.xlsx', '.xls']:
            # For Excel, use pandas then register with DuckDB
            df = pd.read_excel(file_path)
            conn.register('uploaded_data', df)
            df = conn.execute("SELECT * FROM uploaded_data").df()
        
        st.success(f"✅ Loaded {len(df)} rows and {len(df.columns)} columns")
        
        # Register dataframe for SQL queries
        conn.register('data', df)
        
        # Tabs for different analysis views
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Overview", "🔍 Data Preview", "📈 Visualizations", "🧮 Statistics", "💻 SQL Query"
        ])
        
        with tab1:
            st.subheader("Dataset Overview")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Rows", f"{len(df):,}")
            with col2:
                st.metric("Total Columns", len(df.columns))
            with col3:
                st.metric("Memory Usage", f"{df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
            with col4:
                st.metric("Duplicate Rows", df.duplicated().sum())
            
            st.subheader("Column Information")
            col_info = pd.DataFrame({
                'Column': df.columns,
                'Data Type': df.dtypes.values,
                'Non-Null Count': df.count().values,
                'Null Count': df.isnull().sum().values,
                'Null %': (df.isnull().sum() / len(df) * 100).round(2).values,
                'Unique Values': df.nunique().values
            })
            st.dataframe(col_info, use_container_width=True)
        
        with tab2:
            st.subheader("Data Preview")
            
            col1, col2 = st.columns([3, 1])
            with col1:
                n_rows = st.slider("Number of rows to display", 5, min(100, len(df)), 10)
            with col2:
                view_option = st.selectbox("View", ["Head", "Tail", "Random Sample"])
            
            if view_option == "Head":
                st.dataframe(df.head(n_rows), use_container_width=True)
            elif view_option == "Tail":
                st.dataframe(df.tail(n_rows), use_container_width=True)
            else:
                st.dataframe(df.sample(min(n_rows, len(df))), use_container_width=True)
        
        with tab3:
            st.subheader("Data Visualizations")
            
            # Select numeric and categorical columns
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
            
            if numeric_cols:
                st.markdown("#### Numeric Column Distribution")
                selected_num_col = st.selectbox("Select numeric column", numeric_cols)
                
                col1, col2 = st.columns(2)
                with col1:
                    fig_hist = px.histogram(df, x=selected_num_col, title=f"Distribution of {selected_num_col}")
                    st.plotly_chart(fig_hist, use_container_width=True)
                
                with col2:
                    fig_box = px.box(df, y=selected_num_col, title=f"Box Plot of {selected_num_col}")
                    st.plotly_chart(fig_box, use_container_width=True)
            
            if categorical_cols:
                st.markdown("#### Categorical Column Distribution")
                selected_cat_col = st.selectbox("Select categorical column", categorical_cols)
                
                value_counts = df[selected_cat_col].value_counts().head(20)
                fig_bar = px.bar(x=value_counts.index, y=value_counts.values, 
                                title=f"Top 20 Values in {selected_cat_col}",
                                labels={'x': selected_cat_col, 'y': 'Count'})
                st.plotly_chart(fig_bar, use_container_width=True)
            
            if len(numeric_cols) >= 2:
                st.markdown("#### Correlation Analysis")
                corr_matrix = df[numeric_cols].corr()
                fig_corr = px.imshow(corr_matrix, 
                                    text_auto=True, 
                                    title="Correlation Heatmap",
                                    color_continuous_scale='RdBu_r')
                st.plotly_chart(fig_corr, use_container_width=True)
        
        with tab4:
            st.subheader("Statistical Summary")
            
            if numeric_cols:
                st.markdown("#### Numeric Columns")
                st.dataframe(df[numeric_cols].describe(), use_container_width=True)
            
            if categorical_cols:
                st.markdown("#### Categorical Columns")
                cat_summary = pd.DataFrame({
                    'Column': categorical_cols,
                    'Unique Values': [df[col].nunique() for col in categorical_cols],
                    'Most Frequent': [df[col].mode()[0] if len(df[col].mode()) > 0 else None for col in categorical_cols],
                    'Frequency': [df[col].value_counts().iloc[0] if len(df[col]) > 0 else 0 for col in categorical_cols]
                })
                st.dataframe(cat_summary, use_container_width=True)
        
        with tab5:
            st.subheader("Custom SQL Query")
            st.markdown("Query the data using DuckDB SQL. The table is named `data`.")
            
            # Preset queries
            preset_query = st.selectbox(
                "Preset Queries (optional)",
                ["Custom", "Select All", "Count Rows", "Group By (first categorical)", "Top 10 Rows"]
            )
            
            if preset_query == "Select All":
                default_query = "SELECT * FROM data LIMIT 100"
            elif preset_query == "Count Rows":
                default_query = "SELECT COUNT(*) as total_rows FROM data"
            elif preset_query == "Group By (first categorical)" and categorical_cols:
                default_query = f"SELECT {categorical_cols[0]}, COUNT(*) as count FROM data GROUP BY {categorical_cols[0]} ORDER BY count DESC LIMIT 10"
            elif preset_query == "Top 10 Rows":
                default_query = "SELECT * FROM data LIMIT 10"
            else:
                default_query = "SELECT * FROM data LIMIT 100"
            
            sql_query = st.text_area("SQL Query", default_query, height=100)
            
            if st.button("Execute Query"):
                try:
                    result = conn.execute(sql_query).df()
                    st.success(f"Query returned {len(result)} rows")
                    st.dataframe(result, use_container_width=True)
                    
                    # Option to download results
                    csv = result.to_csv(index=False)
                    st.download_button(
                        label="Download Results as CSV",
                        data=csv,
                        file_name="query_results.csv",
                        mime="text/csv"
                    )
                except Exception as e:
                    st.error(f"Query Error: {str(e)}")
        
        # Download section
        st.sidebar.subheader("📥 Download Data")
        if st.sidebar.button("Download as CSV"):
            csv = df.to_csv(index=False)
            st.sidebar.download_button(
                label="Click to Download",
                data=csv,
                file_name="data_export.csv",
                mime="text/csv"
            )
        
    except Exception as e:
        st.error(f"Error loading file: {str(e)}")
        st.info("Please make sure the file format is correct and try again.")

else:
    st.info("👆 Please upload a file to begin analysis")
    
    # Sample instructions
    with st.expander("ℹ️ How to use this app"):
        st.markdown("""
        1. **Upload** your data file (CSV, Parquet, JSON, or Excel)
        2. **Explore** the data across different tabs:
           - **Overview**: High-level statistics and column information
           - **Data Preview**: View the actual data
           - **Visualizations**: Interactive charts and graphs
           - **Statistics**: Detailed statistical summaries
           - **SQL Query**: Run custom DuckDB SQL queries
        3. **Download** processed data or query results
        
        **Supported Formats:**
        - CSV (.csv)
        - Parquet (.parquet)
        - JSON (.json)
        - Excel (.xlsx, .xls)
        """)
